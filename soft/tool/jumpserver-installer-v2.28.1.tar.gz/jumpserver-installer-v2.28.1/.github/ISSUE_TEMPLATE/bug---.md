---
name: Bug 提交
about: 提交产品缺陷帮助我们更好的改进
title: "[Bug] "
labels: 类型:bug
assignees: wojiushixiaobai

---

**JumpServer 版本(v1.5.9以下不再支持)**


**浏览器版本**


**Bug 描述**


**Bug 重现步骤(有截图更好)**
1.  
2.
3.
