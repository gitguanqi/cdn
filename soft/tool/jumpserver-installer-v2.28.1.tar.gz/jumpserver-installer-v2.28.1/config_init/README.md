# 说明

这里的配置文件只是默认支持，会 copy 到 /opt/jumpserver/config 中，如果编辑请去那里
