# -*- coding: utf-8 -*-
#
from .index import *
from .other import *
from .celery_flower import *
from .swagger import *
from .error_views import *
